var app = angular.module("angular-webagentv1",[]);
app.controller("demoCtrl", function ($scope){
	
	$scope.message = "FrontEnd Development started";
});
